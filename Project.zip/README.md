# Storyline Tracker

# Getting Started

1. Fork and clone this repo

1. `npm i`

1. Run the TypeScript compiler, watch for changes, start the server, and launch the browser `npm start`
