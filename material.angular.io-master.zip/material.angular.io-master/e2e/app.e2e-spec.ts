import {MaterialDocsAppPage} from './app.po';

describe('angular-io-v42 App', function() {
  let page: MaterialDocsAppPage;

  beforeEach(() => {
    page = new MaterialDocsAppPage();
  });

  it('should do something', () => {
    expect(1).toBe(1);
  });
});
