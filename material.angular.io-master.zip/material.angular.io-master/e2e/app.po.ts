import {browser} from 'protractor';

export class MaterialDocsAppPage {

}
