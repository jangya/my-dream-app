#!/bin/bash
cp src/app/examples src/assets/plunker -r
